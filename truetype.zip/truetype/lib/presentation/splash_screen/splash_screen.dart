import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoAnimationController;
  late AnimationController _loadingAnimationController;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _logoOpacityAnimation;
  late Animation<double> _loadingOpacityAnimation;

  bool _isInitializing = true;
  bool _hasError = false;
  String _errorMessage = '';
  int _retryCount = 0;
  static const int _maxRetries = 3;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startSplashSequence();
  }

  void _initializeAnimations() {
    _logoAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _loadingAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _logoScaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: Curves.elasticOut,
    ));

    _logoOpacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
    ));

    _loadingOpacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _loadingAnimationController,
      curve: Curves.easeIn,
    ));
  }

  Future<void> _startSplashSequence() async {
    try {
      // Start logo animation
      _logoAnimationController.forward();

      // Wait for logo animation to complete partially
      await Future.delayed(const Duration(milliseconds: 800));

      // Start loading animation
      _loadingAnimationController.forward();

      // Perform initialization tasks
      await _performInitialization();

      // Navigate based on initialization results
      await _navigateToNextScreen();
    } catch (e) {
      _handleInitializationError(e.toString());
    }
  }

  Future<void> _performInitialization() async {
    setState(() {
      _isInitializing = true;
      _hasError = false;
    });

    try {
      // Simulate checking authentication status
      await Future.delayed(const Duration(milliseconds: 500));

      // Simulate loading user preferences
      await Future.delayed(const Duration(milliseconds: 300));

      // Simulate initializing audio services
      await Future.delayed(const Duration(milliseconds: 400));

      // Simulate preparing cached practice data
      await Future.delayed(const Duration(milliseconds: 300));

      // Simulate network connectivity check
      await Future.delayed(const Duration(milliseconds: 200));

      setState(() {
        _isInitializing = false;
      });
    } catch (e) {
      throw Exception('Initialization failed: ${e.toString()}');
    }
  }

  void _handleInitializationError(String error) {
    setState(() {
      _hasError = true;
      _errorMessage = error;
      _isInitializing = false;
    });
  }

  Future<void> _navigateToNextScreen() async {
    if (_hasError) return;

    // Wait for minimum splash duration
    await Future.delayed(const Duration(milliseconds: 800));

    if (!mounted) return;

    // Mock authentication check - in real app, check actual auth status
    final bool isAuthenticated = false; // Mock value
    final bool isFirstTime = true; // Mock value

    if (isAuthenticated) {
      // Navigate to Practice Dashboard (not implemented in this scope)
      Navigator.pushReplacementNamed(context, '/audio-library');
    } else if (isFirstTime) {
      // Navigate to onboarding (using login as placeholder)
      Navigator.pushReplacementNamed(context, '/login-screen');
    } else {
      // Navigate to login screen
      Navigator.pushReplacementNamed(context, '/login-screen');
    }
  }

  Future<void> _retryInitialization() async {
    if (_retryCount >= _maxRetries) {
      setState(() {
        _errorMessage =
            'Maximum retry attempts reached. Please restart the app.';
      });
      return;
    }

    _retryCount++;
    setState(() {
      _hasError = false;
      _errorMessage = '';
    });

    // Reset animations
    _logoAnimationController.reset();
    _loadingAnimationController.reset();

    // Restart splash sequence
    await _startSplashSequence();
  }

  @override
  void dispose() {
    _logoAnimationController.dispose();
    _loadingAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarColor: AppTheme.lightTheme.primaryColor,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
        child: Container(
          width: 100.w,
          height: 100.h,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppTheme.lightTheme.primaryColor,
                AppTheme.lightTheme.primaryColor.withValues(alpha: 0.8),
                AppTheme.lightTheme.colorScheme.secondary
                    .withValues(alpha: 0.6),
              ],
            ),
          ),
          child: SafeArea(
            child: _hasError ? _buildErrorView() : _buildSplashContent(),
          ),
        ),
      ),
    );
  }

  Widget _buildSplashContent() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          flex: 3,
          child: Center(
            child: AnimatedBuilder(
              animation: _logoAnimationController,
              builder: (context, child) {
                return Opacity(
                  opacity: _logoOpacityAnimation.value,
                  child: Transform.scale(
                    scale: _logoScaleAnimation.value,
                    child: _buildLogo(),
                  ),
                );
              },
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: AnimatedBuilder(
            animation: _loadingAnimationController,
            builder: (context, child) {
              return Opacity(
                opacity: _loadingOpacityAnimation.value,
                child: _buildLoadingSection(),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLogo() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 25.w,
          height: 25.w,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(4.w),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.2),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Center(
            child: Text(
              'TT',
              style: TextStyle(
                fontSize: 8.w,
                fontWeight: FontWeight.bold,
                color: AppTheme.lightTheme.primaryColor,
                letterSpacing: -0.5,
              ),
            ),
          ),
        ),
        SizedBox(height: 3.h),
        Text(
          'TrueType',
          style: TextStyle(
            fontSize: 6.w,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 1.2,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Verbatim Transcription Training',
          style: TextStyle(
            fontSize: 3.5.w,
            fontWeight: FontWeight.w400,
            color: Colors.white.withValues(alpha: 0.9),
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingSection() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: 8.w,
          height: 8.w,
          child: CircularProgressIndicator(
            strokeWidth: 2.0,
            valueColor: AlwaysStoppedAnimation<Color>(
              Colors.white.withValues(alpha: 0.8),
            ),
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          _isInitializing ? 'Initializing services...' : 'Ready to start',
          style: TextStyle(
            fontSize: 3.w,
            fontWeight: FontWeight.w400,
            color: Colors.white.withValues(alpha: 0.8),
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildErrorView() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'error_outline',
            color: Colors.white,
            size: 15.w,
          ),
          SizedBox(height: 3.h),
          Text(
            'Initialization Failed',
            style: TextStyle(
              fontSize: 5.w,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 2.h),
          Text(
            _errorMessage.isNotEmpty
                ? _errorMessage
                : 'Unable to initialize the app. Please check your connection and try again.',
            style: TextStyle(
              fontSize: 3.5.w,
              fontWeight: FontWeight.w400,
              color: Colors.white.withValues(alpha: 0.9),
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 4.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed:
                    _retryCount < _maxRetries ? _retryInitialization : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: AppTheme.lightTheme.primaryColor,
                  padding: EdgeInsets.symmetric(
                    horizontal: 6.w,
                    vertical: 1.5.h,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                ),
                child: Text(
                  'Retry (${_maxRetries - _retryCount})',
                  style: TextStyle(
                    fontSize: 3.5.w,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              OutlinedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/login-screen');
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white, width: 1.0),
                  padding: EdgeInsets.symmetric(
                    horizontal: 6.w,
                    vertical: 1.5.h,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                ),
                child: Text(
                  'Continue',
                  style: TextStyle(
                    fontSize: 3.5.w,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
