import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SubscriptionSectionWidget extends StatelessWidget {
  const SubscriptionSectionWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    // Mock subscription data
    final Map<String, dynamic> subscriptionData = {
      "plan": "Premium",
      "price": "\$19.99/month",
      "renewalDate": "March 15, 2024",
      "sessionsUsed": 247,
      "sessionsLimit": 500,
      "storageUsed": "2.3 GB",
      "storageLimit": "10 GB"
    };

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Subscription',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: isDark
                      ? AppTheme.accentDark.withValues(alpha: 0.2)
                      : AppTheme.accentLight.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  subscriptionData["plan"] as String,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: isDark ? AppTheme.accentDark : AppTheme.accentLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Plan Details
          _buildDetailRow(
            context,
            'Price',
            subscriptionData["price"] as String,
            'attach_money',
          ),

          SizedBox(height: 1.h),

          _buildDetailRow(
            context,
            'Next Renewal',
            subscriptionData["renewalDate"] as String,
            'calendar_today',
          ),

          SizedBox(height: 2.h),

          // Usage Statistics
          Text(
            'Usage Statistics',
            style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              fontWeight: FontWeight.w500,
            ),
          ),

          SizedBox(height: 1.h),

          // Sessions Usage
          _buildUsageBar(
            context,
            'Practice Sessions',
            subscriptionData["sessionsUsed"] as int,
            subscriptionData["sessionsLimit"] as int,
            '${subscriptionData["sessionsUsed"]}/${subscriptionData["sessionsLimit"]}',
          ),

          SizedBox(height: 1.h),

          // Storage Usage
          _buildUsageBar(
            context,
            'Storage',
            23, // 2.3 GB out of 10 GB = 23%
            100,
            '${subscriptionData["storageUsed"]}/${subscriptionData["storageLimit"]}',
          ),

          SizedBox(height: 2.h),

          // Upgrade Button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => _showUpgradeDialog(context),
              child: Text('Manage Subscription'),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(
      BuildContext context, String label, String value, String iconName) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Row(
      children: [
        CustomIconWidget(
          iconName: iconName,
          color:
              isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight,
          size: 20,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: isDark
                      ? AppTheme.textSecondaryDark
                      : AppTheme.textSecondaryLight,
                ),
              ),
              Text(
                value,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildUsageBar(BuildContext context, String label, int used, int total,
      String displayText) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final double percentage = used / total;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: isDark
                    ? AppTheme.textPrimaryDark
                    : AppTheme.textPrimaryLight,
              ),
            ),
            Text(
              displayText,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Container(
          width: double.infinity,
          height: 6,
          decoration: BoxDecoration(
            color: isDark ? AppTheme.borderDark : AppTheme.borderLight,
            borderRadius: BorderRadius.circular(3),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: percentage,
            child: Container(
              decoration: BoxDecoration(
                color: percentage > 0.8
                    ? AppTheme.warningLight
                    : (isDark ? AppTheme.primaryDark : AppTheme.primaryLight),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showUpgradeDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Manage Subscription'),
        content: Text(
            'Subscription management options:\n• Upgrade Plan\n• Change Payment Method\n• Cancel Subscription\n• View Billing History'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Manage'),
          ),
        ],
      ),
    );
  }
}
