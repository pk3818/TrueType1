import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/account_info_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/security_section_widget.dart';
import './widgets/settings_section_widget.dart';
import './widgets/subscription_section_widget.dart';
import './widgets/support_section_widget.dart';

class UserProfileSettings extends StatefulWidget {
  const UserProfileSettings({Key? key}) : super(key: key);

  @override
  State<UserProfileSettings> createState() => _UserProfileSettingsState();
}

class _UserProfileSettingsState extends State<UserProfileSettings> {
  // Mock user data
  final Map<String, dynamic> userData = {
    "name": "Sarah Johnson",
    "title": "Certified Court Reporter",
    "email": "sarah.johnson@email.com",
    "avatar":
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
    "membershipStatus": "Premium",
    "practiceStreak": 15,
    "totalSessions": 247,
    "accuracyRate": 94.2,
    "wordsPerMinute": 180
  };

  // Settings state
  bool practiceReminders = true;
  bool achievementAlerts = true;
  bool weeklyReports = false;
  bool dataSharing = false;
  bool analyticsParticipation = true;
  bool profileVisibility = true;
  bool autoDownload = true;
  bool biometricAuth = false;
  bool twoFactorAuth = false;

  double audioSpeed = 1.0;
  String defaultDifficulty = "Intermediate";
  String typingInterface = "Standard";
  String audioQuality = "High";
  String storageLocation = "Internal";

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: AppBar(
        title: Text(
          'Profile Settings',
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: Colors.white,
            size: 24,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Header
              ProfileHeaderWidget(
                userData: userData,
                onEditPressed: () => _showEditProfileDialog(),
              ),

              SizedBox(height: 3.h),

              // Account Information
              AccountInfoWidget(userData: userData),

              SizedBox(height: 3.h),

              // Practice Preferences
              SettingsSectionWidget(
                title: "Practice Preferences",
                children: [
                  _buildDropdownSetting(
                    "Default Difficulty",
                    defaultDifficulty,
                    ["Beginner", "Intermediate", "Advanced", "Expert"],
                    (value) => setState(() => defaultDifficulty = value!),
                  ),
                  _buildSliderSetting(
                    "Audio Speed",
                    audioSpeed,
                    0.5,
                    2.0,
                    (value) => setState(() => audioSpeed = value),
                    "${audioSpeed.toStringAsFixed(1)}x",
                  ),
                  _buildDropdownSetting(
                    "Typing Interface",
                    typingInterface,
                    ["Standard", "Compact", "Large Keys"],
                    (value) => setState(() => typingInterface = value!),
                  ),
                ],
              ),

              SizedBox(height: 2.h),

              // Notifications
              SettingsSectionWidget(
                title: "Notifications",
                children: [
                  _buildSwitchSetting(
                    "Practice Reminders",
                    practiceReminders,
                    (value) => setState(() => practiceReminders = value),
                  ),
                  _buildSwitchSetting(
                    "Achievement Alerts",
                    achievementAlerts,
                    (value) => setState(() => achievementAlerts = value),
                  ),
                  _buildSwitchSetting(
                    "Weekly Reports",
                    weeklyReports,
                    (value) => setState(() => weeklyReports = value),
                  ),
                ],
              ),

              SizedBox(height: 2.h),

              // Audio Settings
              SettingsSectionWidget(
                title: "Audio Settings",
                children: [
                  _buildDropdownSetting(
                    "Audio Quality",
                    audioQuality,
                    ["Standard", "High", "Lossless"],
                    (value) => setState(() => audioQuality = value!),
                  ),
                  _buildDropdownSetting(
                    "Storage Location",
                    storageLocation,
                    ["Internal", "SD Card", "Cloud"],
                    (value) => setState(() => storageLocation = value!),
                  ),
                  _buildSwitchSetting(
                    "Auto-Download",
                    autoDownload,
                    (value) => setState(() => autoDownload = value),
                  ),
                ],
              ),

              SizedBox(height: 2.h),

              // Privacy Controls
              SettingsSectionWidget(
                title: "Privacy Controls",
                children: [
                  _buildSwitchSetting(
                    "Data Sharing",
                    dataSharing,
                    (value) => setState(() => dataSharing = value),
                  ),
                  _buildSwitchSetting(
                    "Analytics Participation",
                    analyticsParticipation,
                    (value) => setState(() => analyticsParticipation = value),
                  ),
                  _buildSwitchSetting(
                    "Profile Visibility",
                    profileVisibility,
                    (value) => setState(() => profileVisibility = value),
                  ),
                ],
              ),

              SizedBox(height: 2.h),

              // Subscription Management
              SubscriptionSectionWidget(),

              SizedBox(height: 2.h),

              // Security Settings
              SecuritySectionWidget(
                biometricAuth: biometricAuth,
                twoFactorAuth: twoFactorAuth,
                onBiometricChanged: (value) =>
                    setState(() => biometricAuth = value),
                onTwoFactorChanged: (value) =>
                    setState(() => twoFactorAuth = value),
                onPasswordChange: () => _showPasswordChangeDialog(),
                onSessionManagement: () => _showActiveSessionsDialog(),
              ),

              SizedBox(height: 2.h),

              // Support Section
              SupportSectionWidget(),

              SizedBox(height: 3.h),

              // Export Data Button
              _buildExportDataButton(),

              SizedBox(height: 2.h),

              // Logout Button
              _buildLogoutButton(),

              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSwitchSetting(
      String title, bool value, Function(bool) onChanged) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              title,
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: isDark
                    ? AppTheme.textPrimaryDark
                    : AppTheme.textPrimaryLight,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownSetting(String title, String value, List<String> options,
      Function(String?) onChanged) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 3.w),
            decoration: BoxDecoration(
              border: Border.all(
                color: isDark ? AppTheme.borderDark : AppTheme.borderLight,
              ),
              borderRadius: BorderRadius.circular(8),
              color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                onChanged: onChanged,
                items: options.map((String option) {
                  return DropdownMenuItem<String>(
                    value: option,
                    child: Text(
                      option,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                      ),
                    ),
                  );
                }).toList(),
                dropdownColor:
                    isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
                icon: CustomIconWidget(
                  iconName: 'keyboard_arrow_down',
                  color: isDark
                      ? AppTheme.textSecondaryDark
                      : AppTheme.textSecondaryLight,
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliderSetting(String title, double value, double min, double max,
      Function(double) onChanged, String displayValue) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                displayValue,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: ((max - min) * 10).round(),
            onChanged: onChanged,
            activeColor: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
            inactiveColor: isDark ? AppTheme.borderDark : AppTheme.borderLight,
          ),
        ],
      ),
    );
  }

  Widget _buildExportDataButton() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: OutlinedButton.icon(
        onPressed: () => _showExportDataDialog(),
        icon: CustomIconWidget(
          iconName: 'download',
          color: AppTheme.primaryLight,
          size: 20,
        ),
        label: Text('Export Practice Data'),
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 2.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }

  Widget _buildLogoutButton() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: ElevatedButton.icon(
        onPressed: () => _showLogoutDialog(),
        icon: CustomIconWidget(
          iconName: 'logout',
          color: Colors.white,
          size: 20,
        ),
        label: Text('Logout'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.errorLight,
          foregroundColor: Colors.white,
          padding: EdgeInsets.symmetric(vertical: 2.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }

  void _showEditProfileDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Profile'),
        content:
            Text('Profile editing functionality would be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showPasswordChangeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Change Password'),
        content:
            Text('Password change functionality would be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showActiveSessionsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Active Sessions'),
        content:
            Text('Session management functionality would be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showExportDataDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Export Data'),
        content: Text('Choose export format:\n• CSV\n• JSON\n• PDF Report'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Data export started...')),
              );
            },
            child: Text('Export'),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Logout'),
        content: Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/login-screen',
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorLight,
            ),
            child: Text('Logout'),
          ),
        ],
      ),
    );
  }
}
