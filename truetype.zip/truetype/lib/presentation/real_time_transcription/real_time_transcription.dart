import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';
import 'package:speech_to_text/speech_to_text.dart';

import './widgets/accuracy_metrics_widget.dart';
import './widgets/audio_controls_widget.dart';
import './widgets/microphone_control_widget.dart';
import './widgets/transcription_text_display_widget.dart';
import './widgets/waveform_visualization_widget.dart';

class RealTimeTranscription extends StatefulWidget {
  const RealTimeTranscription({super.key});

  @override
  State<RealTimeTranscription> createState() => _RealTimeTranscriptionState();
}

class _RealTimeTranscriptionState extends State<RealTimeTranscription> {
  final SpeechToText _speechToText = SpeechToText();
  bool _speechEnabled = false;
  bool _isListening = false;
  String _transcriptionText = '';
  String _lastWords = '';
  double _confidenceLevel = 0.0;
  double _audioLevel = 0.0;
  int _wordsPerMinute = 0;
  double _accuracyPercentage = 0.0;
  double _errorRate = 0.0;

  // Audio control settings
  double _sensitivity = 0.5;
  bool _noiseCancellation = true;
  bool _speakerIdentification = false;

  // Transcription session data
  DateTime? _sessionStartTime;
  List<String> _transcriptionHistory = [];

  @override
  void initState() {
    super.initState();
    _initSpeech();
  }

  void _initSpeech() async {
    final permissionStatus = await Permission.microphone.request();
    if (permissionStatus.isGranted) {
      _speechEnabled = await _speechToText.initialize(
        onError: (error) {
          setState(() {
            _isListening = false;
          });
          _showErrorMessage('Speech recognition error: ${error.errorMsg}');
        },
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            setState(() {
              _isListening = false;
            });
          }
        },
      );
    } else {
      _showErrorMessage('Microphone permission is required for transcription');
    }
    setState(() {});
  }

  void _startListening() async {
    if (_speechEnabled && !_isListening) {
      setState(() {
        _isListening = true;
        _sessionStartTime = DateTime.now();
        _transcriptionText = '';
        _transcriptionHistory.clear();
      });

      // Haptic feedback
      HapticFeedback.lightImpact();

      await _speechToText.listen(
        onResult: (result) {
          setState(() {
            _transcriptionText = result.recognizedWords;
            _lastWords = result.recognizedWords;
            _confidenceLevel = result.confidence;
            _audioLevel = result.confidence; // Simulated audio level

            // Calculate metrics
            _calculateMetrics();

            // Add to history if final result
            if (result.finalResult) {
              _transcriptionHistory.add(result.recognizedWords);
            }
          });
        },
        listenFor: const Duration(minutes: 30),
        pauseFor: const Duration(seconds: 3),
        partialResults: true,
        localeId: 'en_US',
        onSoundLevelChange: (level) {
          setState(() {
            _audioLevel = level;
          });
        },
      );
    }
  }

  void _stopListening() async {
    if (_isListening) {
      await _speechToText.stop();
      setState(() {
        _isListening = false;
      });

      // Haptic feedback
      HapticFeedback.mediumImpact();
    }
  }

  void _calculateMetrics() {
    if (_sessionStartTime != null && _transcriptionText.isNotEmpty) {
      final sessionDuration = DateTime.now().difference(_sessionStartTime!);
      final wordCount = _transcriptionText.split(' ').length;

      // Calculate WPM
      _wordsPerMinute = sessionDuration.inMinutes > 0
          ? (wordCount / sessionDuration.inMinutes).round()
          : 0;

      // Simulate accuracy metrics (in real implementation, compare with reference)
      _accuracyPercentage = _confidenceLevel * 100;
      _errorRate = (1 - _confidenceLevel) * 100;
    }
  }

  void _exportTranscription() {
    if (_transcriptionText.isNotEmpty) {
      // In real implementation, integrate with file system
      _showSuccessMessage('Transcription exported successfully');
    }
  }

  void _clearTranscription() {
    setState(() {
      _transcriptionText = '';
      _transcriptionHistory.clear();
      _sessionStartTime = null;
      _wordsPerMinute = 0;
      _accuracyPercentage = 0.0;
      _errorRate = 0.0;
    });
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Theme.of(context).colorScheme.error,
      ),
    );
  }

  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Theme.of(context).colorScheme.tertiary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Real-Time Transcription',
          style: Theme.of(context).appBarTheme.titleTextStyle,
        ),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        foregroundColor: Theme.of(context).appBarTheme.foregroundColor,
        elevation: Theme.of(context).appBarTheme.elevation,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              _showSettingsDialog();
            },
          ),
          IconButton(
            icon: const Icon(Icons.clear),
            onPressed: _clearTranscription,
          ),
        ],
      ),
      body: !_speechEnabled
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.mic_off,
                    size: 64.sp,
                    color: Theme.of(context).colorScheme.error,
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    'Speech recognition not available',
                    style: Theme.of(context).textTheme.headlineSmall,
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'Please check microphone permissions',
                    style: Theme.of(context).textTheme.bodyMedium,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          : Column(
              children: [
                // Transcription text display
                Expanded(
                  flex: 3,
                  child: TranscriptionTextDisplayWidget(
                    transcriptionText: _transcriptionText,
                    isListening: _isListening,
                  ),
                ),

                // Waveform visualization
                Container(
                  height: 80.h,
                  margin: EdgeInsets.symmetric(horizontal: 16.w),
                  child: WaveformVisualizationWidget(
                    audioLevel: _audioLevel,
                    isListening: _isListening,
                  ),
                ),

                SizedBox(height: 16.h),

                // Microphone control
                MicrophoneControlWidget(
                  isListening: _isListening,
                  onStartListening: _startListening,
                  onStopListening: _stopListening,
                  speechEnabled: _speechEnabled,
                ),

                SizedBox(height: 16.h),

                // Audio controls
                AudioControlsWidget(
                  sensitivity: _sensitivity,
                  noiseCancellation: _noiseCancellation,
                  speakerIdentification: _speakerIdentification,
                  onSensitivityChanged: (value) {
                    setState(() {
                      _sensitivity = value;
                    });
                  },
                  onNoiseCancellationChanged: (value) {
                    setState(() {
                      _noiseCancellation = value;
                    });
                  },
                  onSpeakerIdentificationChanged: (value) {
                    setState(() {
                      _speakerIdentification = value;
                    });
                  },
                ),

                SizedBox(height: 16.h),

                // Accuracy metrics
                AccuracyMetricsWidget(
                  wordsPerMinute: _wordsPerMinute,
                  accuracyPercentage: _accuracyPercentage,
                  errorRate: _errorRate,
                  confidenceLevel: _confidenceLevel,
                ),

                SizedBox(height: 16.h),

                // Export button
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 16.w),
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _transcriptionText.isNotEmpty
                        ? _exportTranscription
                        : null,
                    icon: const Icon(Icons.download),
                    label: const Text('Export Transcription'),
                  ),
                ),

                SizedBox(height: 16.h),
              ],
            ),
    );
  }

  void _showSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Transcription Settings'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Audio Quality'),
              subtitle: const Text('High quality processing'),
              trailing: Switch(
                value: true,
                onChanged: (value) {},
              ),
            ),
            ListTile(
              title: const Text('Offline Mode'),
              subtitle: const Text('Use device-only processing'),
              trailing: Switch(
                value: false,
                onChanged: (value) {},
              ),
            ),
            ListTile(
              title: const Text('Auto-punctuation'),
              subtitle: const Text('Automatically add punctuation'),
              trailing: Switch(
                value: true,
                onChanged: (value) {},
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _speechToText.stop();
    super.dispose();
  }
}
