import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MicrophoneControlWidget extends StatefulWidget {
  final bool isListening;
  final VoidCallback onStartListening;
  final VoidCallback onStopListening;
  final bool speechEnabled;

  const MicrophoneControlWidget({
    super.key,
    required this.isListening,
    required this.onStartListening,
    required this.onStopListening,
    required this.speechEnabled,
  });

  @override
  State<MicrophoneControlWidget> createState() => _MicrophoneControlWidgetState();
}

class _MicrophoneControlWidgetState extends State<MicrophoneControlWidget>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _scaleController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    
    _pulseController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this);
    
    _scaleController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this);
    
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut));
    
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95).animate(CurvedAnimation(
      parent: _scaleController,
      curve: Curves.easeInOut));
    
    if (widget.isListening) {
      _pulseController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(MicrophoneControlWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isListening != oldWidget.isListening) {
      if (widget.isListening) {
        _pulseController.repeat(reverse: true);
      } else {
        _pulseController.stop();
        _pulseController.reset();
      }
    }
  }

  void _handleTap() {
    if (!widget.speechEnabled) return;
    
    // Scale animation for feedback
    _scaleController.forward().then((_) {
      _scaleController.reverse();
    });
    
    // Haptic feedback
    HapticFeedback.mediumImpact();
    
    if (widget.isListening) {
      widget.onStopListening();
    } else {
      widget.onStartListening();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w),
      child: Column(
        children: [
          // Main microphone button
          AnimatedBuilder(
            animation: Listenable.merge([_pulseAnimation, _scaleAnimation]),
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  width: 80.w,
                  height: 80.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: widget.isListening
                        ? [
                            BoxShadow(
                              color: Theme.of(context).colorScheme.tertiary.withAlpha(77),
                              blurRadius: 20 * _pulseAnimation.value,
                              spreadRadius: 5 * _pulseAnimation.value),
                          ]
                        : [
                            BoxShadow(
                              color: Theme.of(context).colorScheme.shadow,
                              blurRadius: 8,
                              offset: const Offset(0, 2)),
                          ]),
                  child: Material(
                    shape: const CircleBorder(),
                    color: widget.isListening
                        ? Theme.of(context).colorScheme.error
                        : widget.speechEnabled
                            ? Theme.of(context).colorScheme.tertiary
                            : Theme.of(context).colorScheme.onSurfaceVariant,
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _handleTap,
                      child: Container(
                        width: 80.w,
                        height: 80.w,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle),
                        child: Icon(
                          widget.isListening ? Icons.stop : Icons.mic,
                          color: Colors.white,
                          size: 36.sp))))));
            }),
          
          SizedBox(height: 12.h),
          
          // Status text
          Text(
            widget.isListening
                ? 'Tap to stop recording'
                : widget.speechEnabled
                    ? 'Tap to start recording'
                    : 'Microphone not available',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: widget.isListening
                  ? Theme.of(context).colorScheme.error
                  : Theme.of(context).colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500),
            textAlign: TextAlign.center),
          
          SizedBox(height: 16.h),
          
          // Control buttons row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Pause button
              _buildControlButton(
                context,
                icon: Icons.pause,
                label: 'Pause',
                onPressed: widget.isListening ? widget.onStopListening : null),
              
              // Settings button
              _buildControlButton(
                context,
                icon: Icons.settings,
                label: 'Settings',
                onPressed: () {
                  _showQuickSettings(context);
                }),
              
              // Save button
              _buildControlButton(
                context,
                icon: Icons.save,
                label: 'Save',
                onPressed: widget.isListening ? null : () {
                  // Handle save functionality
                }),
            ]),
        ]));
  }

  Widget _buildControlButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback? onPressed,
  }) {
    return Column(
      children: [
        Container(
          width: 48.w,
          height: 48.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: onPressed != null
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surfaceContainerHighest),
          child: Material(
            shape: const CircleBorder(),
            color: Colors.transparent,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onPressed,
              child: Icon(
                icon,
                color: onPressed != null
                    ? Theme.of(context).colorScheme.onPrimaryContainer
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24.sp)))),
        SizedBox(height: 4.h),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: onPressed != null
                ? Theme.of(context).colorScheme.onSurface
                : Theme.of(context).colorScheme.onSurfaceVariant)),
      ]);
  }

  void _showQuickSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(16.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quick Settings',
              style: Theme.of(context).textTheme.headlineSmall),
            SizedBox(height: 16.h),
            ListTile(
              leading: const Icon(Icons.volume_up),
              title: const Text('Audio Sensitivity'),
              subtitle: const Text('Adjust microphone sensitivity'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pop(context);
              }),
            ListTile(
              leading: const Icon(Icons.noise_control_off),
              title: const Text('Noise Cancellation'),
              subtitle: const Text('Filter background noise'),
              trailing: Switch(
                value: true,
                onChanged: (value) {})),
            ListTile(
              leading: const Icon(Icons.language),
              title: const Text('Language'),
              subtitle: const Text('English (US)'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pop(context);
              }),
            SizedBox(height: 16.h),
          ])));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _scaleController.dispose();
    super.dispose();
  }
}