
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class WaveformVisualizationWidget extends StatefulWidget {
  final double audioLevel;
  final bool isListening;

  const WaveformVisualizationWidget({
    super.key,
    required this.audioLevel,
    required this.isListening,
  });

  @override
  State<WaveformVisualizationWidget> createState() =>
      _WaveformVisualizationWidgetState();
}

class _WaveformVisualizationWidgetState
    extends State<WaveformVisualizationWidget> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  List<double> _waveformData = [];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        duration: const Duration(milliseconds: 50), vsync: this);
    _animation = Tween<double>(begin: 0, end: 1).animate(_animationController);

    // Initialize waveform data
    _waveformData = List.generate(50, (index) => 0.0);

    if (widget.isListening) {
      _animationController.repeat();
    }
  }

  @override
  void didUpdateWidget(WaveformVisualizationWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isListening != oldWidget.isListening) {
      if (widget.isListening) {
        _animationController.repeat();
      } else {
        _animationController.stop();
      }
    }

    if (widget.audioLevel != oldWidget.audioLevel) {
      _updateWaveformData();
    }
  }

  void _updateWaveformData() {
    setState(() {
      // Shift existing data left
      for (int i = 0; i < _waveformData.length - 1; i++) {
        _waveformData[i] = _waveformData[i + 1];
      }

      // Add new data point
      _waveformData[_waveformData.length - 1] = widget.audioLevel;
    });
  }

  Color _getIntensityColor(double level) {
    if (level < 0.3) {
      return Theme.of(context).colorScheme.tertiary; // Green for low
    } else if (level < 0.7) {
      return Colors.orange; // Orange for medium
    } else {
      return Theme.of(context).colorScheme.error; // Red for high
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration:
            BoxDecoration(color: Theme.of(context).cardColor, boxShadow: [
          BoxShadow(
              color: Theme.of(context).colorScheme.shadow,
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ]),
        child: Column(children: [
          // Header
          Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.only()),
              child: Row(children: [
                Icon(Icons.graphic_eq,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: 20.sp),
                SizedBox(width: 8.w),
                Text('Audio Waveform',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w600)),
                const Spacer(),
                Text('Level: ${(widget.audioLevel * 100).toInt()}%',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w500)),
              ])),

          // Waveform display
          Expanded(
              child: Container(
                  padding: EdgeInsets.all(8.w),
                  child: widget.isListening
                      ? AnimatedBuilder(
                          animation: _animation,
                          builder: (context, child) {
                            return CustomPaint(
                                painter: WaveformPainter(
                                    waveformData: _waveformData,
                                    animationValue: _animation.value,
                                    color:
                                        _getIntensityColor(widget.audioLevel),
                                    backgroundColor:
                                        Theme.of(context).colorScheme.surface,
                                    isListening: widget.isListening),
                                size: Size.infinite);
                          })
                      : Container(
                          decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.surface),
                          child: Center(
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                Icon(Icons.mic_off,
                                    size: 24.sp,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant),
                                SizedBox(height: 8.h),
                                Text('Audio visualization inactive',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall
                                        ?.copyWith(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onSurfaceVariant)),
                              ]))))),
        ]));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}

class WaveformPainter extends CustomPainter {
  final List<double> waveformData;
  final double animationValue;
  final Color color;
  final Color backgroundColor;
  final bool isListening;

  WaveformPainter({
    required this.waveformData,
    required this.animationValue,
    required this.color,
    required this.backgroundColor,
    required this.isListening,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    final backgroundPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;

    // Draw background
    canvas.drawRect(
        Rect.fromLTWH(0, 0, size.width, size.height), backgroundPaint);

    if (waveformData.isEmpty) return;

    final barWidth = size.width / waveformData.length;
    final centerY = size.height / 2;

    for (int i = 0; i < waveformData.length; i++) {
      final x = i * barWidth;
      final amplitude = waveformData[i] * centerY;

      // Create gradient effect based on position
      final opacity =
          isListening ? (0.3 + (i / waveformData.length) * 0.7) : 0.3;
      final barPaint = Paint()
        ..color = color.withOpacity(opacity)
        ..strokeWidth = barWidth * 0.8
        ..strokeCap = StrokeCap.round;

      // Draw waveform bars
      canvas.drawLine(Offset(x + barWidth / 2, centerY - amplitude),
          Offset(x + barWidth / 2, centerY + amplitude), barPaint);
    }

    // Draw center line
    final centerLinePaint = Paint()
      ..color = color.withAlpha(77)
      ..strokeWidth = 1.0;

    canvas.drawLine(
        Offset(0, centerY), Offset(size.width, centerY), centerLinePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
