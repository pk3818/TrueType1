import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class AccuracyMetricsWidget extends StatelessWidget {
  final int wordsPerMinute;
  final double accuracyPercentage;
  final double errorRate;
  final double confidenceLevel;

  const AccuracyMetricsWidget({
    super.key,
    required this.wordsPerMinute,
    required this.accuracyPercentage,
    required this.errorRate,
    required this.confidenceLevel,
  });

  Color _getPerformanceColor(BuildContext context, double percentage) {
    if (percentage >= 90) {
      return Theme.of(context).colorScheme.tertiary; // Excellent - Green
    } else if (percentage >= 75) {
      return Colors.orange; // Good - Orange
    } else if (percentage >= 60) {
      return Colors.amber; // Fair - Amber
    } else {
      return Theme.of(context).colorScheme.error; // Poor - Red
    }
  }

  String _getPerformanceLabel(double percentage) {
    if (percentage >= 90) {
      return 'Excellent';
    } else if (percentage >= 75) {
      return 'Good';
    } else if (percentage >= 60) {
      return 'Fair';
    } else {
      return 'Needs Improvement';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 16.w),
        decoration:
            BoxDecoration(color: Theme.of(context).cardColor, boxShadow: [
          BoxShadow(
              color: Theme.of(context).colorScheme.shadow,
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header
          Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.only()),
              child: Row(children: [
                Icon(Icons.analytics,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: 20.sp),
                SizedBox(width: 8.w),
                Text('Performance Metrics',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w600)),
                const Spacer(),
                Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                    decoration: BoxDecoration(
                        color:
                            _getPerformanceColor(context, accuracyPercentage)),
                    child: Text(_getPerformanceLabel(accuracyPercentage),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.white, fontWeight: FontWeight.w600))),
              ])),

          // Metrics grid
          Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(children: [
                // Top row - Primary metrics
                Row(children: [
                  Expanded(
                      child: _buildMetricCard(context,
                          title: 'Words/Min',
                          value: '$wordsPerMinute',
                          subtitle: 'Typing Speed',
                          icon: Icons.speed,
                          color: Theme.of(context).colorScheme.primary)),
                  SizedBox(width: 12.w),
                  Expanded(
                      child: _buildMetricCard(context,
                          title: 'Accuracy',
                          value: '${accuracyPercentage.toInt()}%',
                          subtitle: 'Recognition Rate',
                          icon: Icons.check_circle,
                          color: _getPerformanceColor(
                              context, accuracyPercentage))),
                ]),

                SizedBox(height: 12.h),

                // Bottom row - Secondary metrics
                Row(children: [
                  Expanded(
                      child: _buildMetricCard(context,
                          title: 'Error Rate',
                          value: '${errorRate.toInt()}%',
                          subtitle: 'Correction Needed',
                          icon: Icons.error_outline,
                          color: errorRate > 25
                              ? Theme.of(context).colorScheme.error
                              : Theme.of(context).colorScheme.secondary)),
                  SizedBox(width: 12.w),
                  Expanded(
                      child: _buildMetricCard(context,
                          title: 'Confidence',
                          value: '${(confidenceLevel * 100).toInt()}%',
                          subtitle: 'AI Certainty',
                          icon: Icons.psychology,
                          color: confidenceLevel > 0.8
                              ? Theme.of(context).colorScheme.tertiary
                              : Theme.of(context).colorScheme.secondary)),
                ]),

                SizedBox(height: 16.h),

                // Accuracy visualization
                _buildAccuracyChart(context),
              ])),
        ]));
  }

  Widget _buildMetricCard(
    BuildContext context, {
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
            color: color.withAlpha(26),
            border: Border.all(color: color.withAlpha(51), width: 1)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: color, size: 16.sp),
            SizedBox(width: 4.w),
            Expanded(
                child: Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: color, fontWeight: FontWeight.w600))),
          ]),
          SizedBox(height: 4.h),
          Text(value,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(color: color, fontWeight: FontWeight.w700)),
          Text(subtitle,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]));
  }

  Widget _buildAccuracyChart(BuildContext context) {
    return Container(
        height: 80.h,
        decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            border: Border.all(
                color: Theme.of(context).colorScheme.outline, width: 1)),
        child: Padding(
            padding: EdgeInsets.all(8.w),
            child: Row(children: [
              // Accuracy gauge
              Expanded(
                  flex: 2,
                  child: Stack(alignment: Alignment.center, children: [
                    SizedBox(
                        width: 60.w,
                        height: 60.w,
                        child: CircularProgressIndicator(
                            value: accuracyPercentage / 100,
                            strokeWidth: 6,
                            backgroundColor:
                                Theme.of(context).colorScheme.outline,
                            valueColor: AlwaysStoppedAnimation<Color>(
                                _getPerformanceColor(
                                    context, accuracyPercentage)))),
                    Text('${accuracyPercentage.toInt()}%',
                        style: Theme.of(context)
                            .textTheme
                            .titleSmall
                            ?.copyWith(fontWeight: FontWeight.w700)),
                  ])),

              // Metrics breakdown
              Expanded(
                  flex: 3,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildMiniMetric(
                            context,
                            'Speed',
                            '$wordsPerMinute WPM',
                            wordsPerMinute > 40 ? Colors.green : Colors.orange),
                        SizedBox(height: 4.h),
                        _buildMiniMetric(
                            context,
                            'Quality',
                            '${(confidenceLevel * 100).toInt()}%',
                            confidenceLevel > 0.8
                                ? Colors.green
                                : Colors.orange),
                        SizedBox(height: 4.h),
                        _buildMiniMetric(
                            context,
                            'Errors',
                            '${errorRate.toInt()}%',
                            errorRate < 15 ? Colors.green : Colors.red),
                      ])),
            ])));
  }

  Widget _buildMiniMetric(
      BuildContext context, String label, String value, Color color) {
    return Row(children: [
      Container(
          width: 8.w,
          height: 8.w,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      SizedBox(width: 8.w),
      Text(label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant)),
      const Spacer(),
      Text(value,
          style: Theme.of(context)
              .textTheme
              .bodySmall
              ?.copyWith(fontWeight: FontWeight.w600, color: color)),
    ]);
  }
}
