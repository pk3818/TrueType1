import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class AudioControlsWidget extends StatelessWidget {
  final double sensitivity;
  final bool noiseCancellation;
  final bool speakerIdentification;
  final ValueChanged<double> onSensitivityChanged;
  final ValueChanged<bool> onNoiseCancellationChanged;
  final ValueChanged<bool> onSpeakerIdentificationChanged;

  const AudioControlsWidget({
    super.key,
    required this.sensitivity,
    required this.noiseCancellation,
    required this.speakerIdentification,
    required this.onSensitivityChanged,
    required this.onNoiseCancellationChanged,
    required this.onSpeakerIdentificationChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 16.w),
        decoration:
            BoxDecoration(color: Theme.of(context).cardColor, boxShadow: [
          BoxShadow(
              color: Theme.of(context).colorScheme.shadow,
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header
          Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.only()),
              child: Row(children: [
                Icon(Icons.tune,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: 20.sp),
                SizedBox(width: 8.w),
                Text('Audio Controls',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w600)),
              ])),

          // Controls content
          Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Sensitivity slider
                    Text('Microphone Sensitivity',
                        style: Theme.of(context)
                            .textTheme
                            .titleSmall
                            ?.copyWith(fontWeight: FontWeight.w600)),
                    SizedBox(height: 8.h),
                    Row(children: [
                      Icon(Icons.volume_down,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          size: 20.sp),
                      Expanded(
                          child: Slider(
                              value: sensitivity,
                              onChanged: onSensitivityChanged,
                              min: 0.0,
                              max: 1.0,
                              divisions: 10,
                              label: '${(sensitivity * 100).toInt()}%',
                              activeColor:
                                  Theme.of(context).colorScheme.primary,
                              inactiveColor:
                                  Theme.of(context).colorScheme.outline)),
                      Icon(Icons.volume_up,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          size: 20.sp),
                    ]),
                    Text('Current: ${(sensitivity * 100).toInt()}%',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceVariant)),

                    SizedBox(height: 20.h),

                    // Toggle controls
                    _buildToggleControl(context,
                        title: 'Noise Cancellation',
                        subtitle: 'Filter background noise and improve clarity',
                        icon: Icons.noise_control_off,
                        value: noiseCancellation,
                        onChanged: onNoiseCancellationChanged),

                    SizedBox(height: 16.h),

                    _buildToggleControl(context,
                        title: 'Speaker Identification',
                        subtitle:
                            'Identify different speakers in multi-person scenarios',
                        icon: Icons.people,
                        value: speakerIdentification,
                        onChanged: onSpeakerIdentificationChanged),

                    SizedBox(height: 20.h),

                    // Additional controls
                    _buildControlsGrid(context),
                  ])),
        ]));
  }

  Widget _buildToggleControl(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
            color: value
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surface,
            border: Border.all(
                color: value
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.outline,
                width: 1)),
        child: Row(children: [
          Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                  color: value
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.surfaceContainerHighest),
              child: Icon(icon,
                  color: value
                      ? Colors.white
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                  size: 20.sp)),
          SizedBox(width: 12.w),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(title,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: value
                            ? Theme.of(context).colorScheme.onPrimaryContainer
                            : Theme.of(context).colorScheme.onSurface)),
                SizedBox(height: 2.h),
                Text(subtitle,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: value
                            ? Theme.of(context).colorScheme.onPrimaryContainer
                            : Theme.of(context).colorScheme.onSurfaceVariant)),
              ])),
          Switch(
              value: value,
              onChanged: onChanged,
              activeColor: Theme.of(context).colorScheme.primary),
        ]));
  }

  Widget _buildControlsGrid(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            border: Border.all(
                color: Theme.of(context).colorScheme.outline, width: 1)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Quick Actions',
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(fontWeight: FontWeight.w600)),
          SizedBox(height: 12.h),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _buildQuickAction(context,
                icon: Icons.mic_external_on, label: 'Test Mic', onTap: () {
              _showTestMicDialog(context);
            }),
            _buildQuickAction(context,
                icon: Icons.equalizer, label: 'Equalizer', onTap: () {
              _showEqualizerDialog(context);
            }),
            _buildQuickAction(context, icon: Icons.language, label: 'Language',
                onTap: () {
              _showLanguageDialog(context);
            }),
            _buildQuickAction(context, icon: Icons.restore, label: 'Reset',
                onTap: () {
              _showResetDialog(context);
            }),
          ]),
        ]));
  }

  Widget _buildQuickAction(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
        onTap: onTap,
        child: Column(children: [
          Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer),
              child: Icon(icon,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  size: 20.sp)),
          SizedBox(height: 4.h),
          Text(label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]));
  }

  void _showTestMicDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
                title: const Text('Microphone Test'),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text(
                      'Speak into your microphone to test audio levels.'),
                  SizedBox(height: 16.h),
                  LinearProgressIndicator(
                      value: 0.7,
                      backgroundColor: Theme.of(context).colorScheme.outline,
                      valueColor: AlwaysStoppedAnimation<Color>(
                          Theme.of(context).colorScheme.tertiary)),
                  SizedBox(height: 8.h),
                  const Text('Audio level: 70%'),
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close')),
                ]));
  }

  void _showEqualizerDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
                title: const Text('Audio Equalizer'),
                content: const Text(
                    'Audio equalizer settings are not available in this version.'),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close')),
                ]));
  }

  void _showLanguageDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
                title: const Text('Language Selection'),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  ListTile(
                      title: const Text('English (US)'),
                      leading: const Icon(Icons.radio_button_checked),
                      onTap: () => Navigator.pop(context)),
                  ListTile(
                      title: const Text('English (UK)'),
                      leading: const Icon(Icons.radio_button_unchecked),
                      onTap: () => Navigator.pop(context)),
                  ListTile(
                      title: const Text('Spanish'),
                      leading: const Icon(Icons.radio_button_unchecked),
                      onTap: () => Navigator.pop(context)),
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel')),
                ]));
  }

  void _showResetDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
                title: const Text('Reset Audio Settings'),
                content: const Text(
                    'Are you sure you want to reset all audio settings to default values?'),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel')),
                  TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        // Reset settings to default
                      },
                      child: const Text('Reset')),
                ]));
  }
}
