import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';


class TranscriptionTextDisplayWidget extends StatefulWidget {
  final String transcriptionText;
  final bool isListening;

  const TranscriptionTextDisplayWidget({
    super.key,
    required this.transcriptionText,
    required this.isListening,
  });

  @override
  State<TranscriptionTextDisplayWidget> createState() =>
      _TranscriptionTextDisplayWidgetState();
}

class _TranscriptionTextDisplayWidgetState
    extends State<TranscriptionTextDisplayWidget> {
  final ScrollController _scrollController = ScrollController();

  @override
  void didUpdateWidget(TranscriptionTextDisplayWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.transcriptionText != oldWidget.transcriptionText) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
              _scrollController.position.maxScrollExtent,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOut);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Container(
        margin: EdgeInsets.all(16.w),
        decoration:
            BoxDecoration(color: Theme.of(context).cardColor, boxShadow: [
          BoxShadow(
              color: Theme.of(context).colorScheme.shadow,
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header
          Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.only()),
              child: Row(children: [
                Icon(Icons.text_fields,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    size: 20.sp),
                SizedBox(width: 8.w),
                Text('Live Transcription',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w600)),
                const Spacer(),
                if (widget.isListening) ...[
                  Container(
                      width: 8.w,
                      height: 8.w,
                      decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.tertiary,
                          shape: BoxShape.circle)),
                  SizedBox(width: 8.w),
                  Text('Recording',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color:
                              Theme.of(context).colorScheme.onPrimaryContainer,
                          fontWeight: FontWeight.w500)),
                ],
              ])),

          // Transcription text area
          Expanded(
              child: Container(
                  padding: EdgeInsets.all(16.w),
                  child: widget.transcriptionText.isEmpty
                      ? Center(
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                              Icon(
                                  widget.isListening
                                      ? Icons.mic
                                      : Icons.mic_none,
                                  size: 48.sp,
                                  color: widget.isListening
                                      ? Theme.of(context).colorScheme.tertiary
                                      : Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant),
                              SizedBox(height: 16.h),
                              Text(
                                  widget.isListening
                                      ? 'Listening for speech...'
                                      : 'Tap the microphone to start transcription',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyLarge
                                      ?.copyWith(
                                          color: Theme.of(context)
                                              .colorScheme
                                              .onSurfaceVariant),
                                  textAlign: TextAlign.center),
                            ]))
                      : Scrollbar(
                          controller: _scrollController,
                          child: SingleChildScrollView(
                              controller: _scrollController,
                              child: SelectableText(widget.transcriptionText,
                                  style: GoogleFonts.jetBrainsMono(
                                      fontSize: 16.sp,
                                      height: 1.5,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface,
                                      fontWeight: FontWeight.w400)))))),

          // Text statistics
          if (widget.transcriptionText.isNotEmpty)
            Container(
                padding: EdgeInsets.all(16.w),
                decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.only()),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem(
                          context,
                          'Words',
                          '${widget.transcriptionText.split(' ').length}',
                          Icons.text_fields),
                      _buildStatItem(
                          context,
                          'Characters',
                          '${widget.transcriptionText.length}',
                          Icons.text_format),
                      _buildStatItem(
                          context,
                          'Lines',
                          '${widget.transcriptionText.split('\n').length}',
                          Icons.format_list_numbered),
                    ])),
        ]));
  }

  Widget _buildStatItem(
      BuildContext context, String label, String value, IconData icon) {
    return Column(children: [
      Icon(icon,
          size: 16.sp, color: Theme.of(context).colorScheme.onSurfaceVariant),
      SizedBox(height: 4.h),
      Text(value,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w600)),
      Text(label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant)),
    ]);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
