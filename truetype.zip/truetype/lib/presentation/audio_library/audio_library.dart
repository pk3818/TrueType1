import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/audio_file_card_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/filter_chip_widget.dart';

class AudioLibrary extends StatefulWidget {
  const AudioLibrary({Key? key}) : super(key: key);

  @override
  State<AudioLibrary> createState() => _AudioLibraryState();
}

class _AudioLibraryState extends State<AudioLibrary> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool _isSearching = false;
  bool _isLoading = false;
  String _selectedFilter = 'All';
  List<String> _selectedAudioIds = [];
  bool _isBulkSelectMode = false;

  // Mock data for audio files
  final List<Map<String, dynamic>> _audioFiles = [
    {
      "id": "1",
      "title": "Legal Deposition - Smith vs. Johnson",
      "duration": "45:32",
      "difficulty": "Advanced",
      "lastPracticed": "2 days ago",
      "waveformUrl":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=60&fit=crop",
      "isFavorite": true,
      "fileSize": "12.5 MB",
      "accuracy": 87.5,
      "practiceCount": 12,
      "tags": ["legal", "deposition", "court"],
      "uploadDate": "2024-01-15",
    },
    {
      "id": "2",
      "title": "Medical Terminology Practice",
      "duration": "23:15",
      "difficulty": "Intermediate",
      "lastPracticed": "1 week ago",
      "waveformUrl":
          "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=300&h=60&fit=crop",
      "isFavorite": false,
      "fileSize": "8.2 MB",
      "accuracy": 92.1,
      "practiceCount": 8,
      "tags": ["medical", "terminology", "healthcare"],
      "uploadDate": "2024-01-10",
    },
    {
      "id": "3",
      "title": "Business Meeting Transcript",
      "duration": "1:12:45",
      "difficulty": "Beginner",
      "lastPracticed": "3 days ago",
      "waveformUrl":
          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=300&h=60&fit=crop",
      "isFavorite": true,
      "fileSize": "18.7 MB",
      "accuracy": 94.3,
      "practiceCount": 15,
      "tags": ["business", "meeting", "corporate"],
      "uploadDate": "2024-01-08",
    },
    {
      "id": "4",
      "title": "Court Hearing - Criminal Case",
      "duration": "2:05:20",
      "difficulty": "Expert",
      "lastPracticed": "5 days ago",
      "waveformUrl":
          "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300&h=60&fit=crop",
      "isFavorite": false,
      "fileSize": "32.1 MB",
      "accuracy": 78.9,
      "practiceCount": 6,
      "tags": ["court", "criminal", "hearing"],
      "uploadDate": "2024-01-05",
    },
    {
      "id": "5",
      "title": "Technical Conference Call",
      "duration": "38:42",
      "difficulty": "Intermediate",
      "lastPracticed": "1 day ago",
      "waveformUrl":
          "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=300&h=60&fit=crop",
      "isFavorite": false,
      "fileSize": "11.3 MB",
      "accuracy": 89.7,
      "practiceCount": 9,
      "tags": ["technical", "conference", "call"],
      "uploadDate": "2024-01-12",
    },
  ];

  final List<String> _filterOptions = [
    'All',
    'Beginner',
    'Intermediate',
    'Advanced',
    'Expert',
    'Favorites',
    'Recent'
  ];

  List<Map<String, dynamic>> get _filteredAudioFiles {
    List<Map<String, dynamic>> filtered = List.from(_audioFiles);

    // Apply search filter
    if (_searchController.text.isNotEmpty) {
      final searchTerm = _searchController.text.toLowerCase();
      filtered = filtered.where((audio) {
        final title = (audio['title'] as String).toLowerCase();
        final tags = (audio['tags'] as List).join(' ').toLowerCase();
        return title.contains(searchTerm) || tags.contains(searchTerm);
      }).toList();
    }

    // Apply difficulty/category filter
    if (_selectedFilter != 'All') {
      if (_selectedFilter == 'Favorites') {
        filtered =
            filtered.where((audio) => audio['isFavorite'] == true).toList();
      } else if (_selectedFilter == 'Recent') {
        filtered.sort((a, b) =>
            (b['uploadDate'] as String).compareTo(a['uploadDate'] as String));
        filtered = filtered.take(10).toList();
      } else {
        filtered = filtered
            .where((audio) => audio['difficulty'] == _selectedFilter)
            .toList();
      }
    }

    return filtered;
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _toggleSearch() {
    setState(() {
      _isSearching = !_isSearching;
      if (!_isSearching) {
        _searchController.clear();
      }
    });
  }

  void _onFilterSelected(String filter) {
    setState(() {
      _selectedFilter = filter;
    });
  }

  void _toggleFavorite(String audioId) {
    setState(() {
      final index = _audioFiles.indexWhere((audio) => audio['id'] == audioId);
      if (index != -1) {
        _audioFiles[index]['isFavorite'] = !_audioFiles[index]['isFavorite'];
      }
    });
  }

  void _deleteAudio(String audioId) {
    setState(() {
      _audioFiles.removeWhere((audio) => audio['id'] == audioId);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Audio file deleted')),
    );
  }

  void _toggleBulkSelect() {
    setState(() {
      _isBulkSelectMode = !_isBulkSelectMode;
      if (!_isBulkSelectMode) {
        _selectedAudioIds.clear();
      }
    });
  }

  void _toggleAudioSelection(String audioId) {
    setState(() {
      if (_selectedAudioIds.contains(audioId)) {
        _selectedAudioIds.remove(audioId);
      } else {
        _selectedAudioIds.add(audioId);
      }
    });
  }

  void _bulkDelete() {
    setState(() {
      _audioFiles
          .removeWhere((audio) => _selectedAudioIds.contains(audio['id']));
      _selectedAudioIds.clear();
      _isBulkSelectMode = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${_selectedAudioIds.length} files deleted')),
    );
  }

  Future<void> _refreshAudioFiles() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Audio library refreshed')),
    );
  }

  void _showImportOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Import Audio Files',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            _buildImportOption(
              icon: 'folder',
              title: 'Device Storage',
              subtitle: 'Browse files on your device',
              onTap: () {
                Navigator.pop(context);
                _importFromDevice();
              },
            ),
            _buildImportOption(
              icon: 'cloud',
              title: 'Cloud Storage',
              subtitle: 'Google Drive, iCloud, Dropbox',
              onTap: () {
                Navigator.pop(context);
                _importFromCloud();
              },
            ),
            _buildImportOption(
              icon: 'link',
              title: 'URL Import',
              subtitle: 'Import from web link',
              onTap: () {
                Navigator.pop(context);
                _importFromUrl();
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildImportOption({
    required String icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.all(4.w),
        margin: EdgeInsets.only(bottom: 2.h),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.lightTheme.colorScheme.outline),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: icon,
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.titleMedium,
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    subtitle,
                    style: AppTheme.lightTheme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'chevron_right',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 5.w,
            ),
          ],
        ),
      ),
    );
  }

  void _importFromDevice() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Opening device file picker...')),
    );
  }

  void _importFromCloud() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connecting to cloud storage...')),
    );
  }

  void _importFromUrl() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Import from URL'),
        content: TextField(
          decoration: const InputDecoration(
            hintText: 'Enter audio file URL',
            prefixIcon: Icon(Icons.link),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Importing audio from URL...')),
              );
            },
            child: const Text('Import'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredFiles = _filteredAudioFiles;

    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
        foregroundColor: AppTheme.lightTheme.appBarTheme.foregroundColor,
        elevation: AppTheme.lightTheme.appBarTheme.elevation,
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: Colors.white,
                ),
                decoration: InputDecoration(
                  hintText: 'Search audio files...',
                  hintStyle:
                      TextStyle(color: Colors.white.withValues(alpha: 0.7)),
                  border: InputBorder.none,
                ),
                onChanged: (value) => setState(() {}),
              )
            : Text(
                'Audio Library',
                style: AppTheme.lightTheme.appBarTheme.titleTextStyle,
              ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: Colors.white,
            size: 6.w,
          ),
        ),
        actions: [
          if (_isBulkSelectMode) ...[
            if (_selectedAudioIds.isNotEmpty)
              IconButton(
                onPressed: _bulkDelete,
                icon: CustomIconWidget(
                  iconName: 'delete',
                  color: Colors.white,
                  size: 6.w,
                ),
              ),
            IconButton(
              onPressed: _toggleBulkSelect,
              icon: CustomIconWidget(
                iconName: 'close',
                color: Colors.white,
                size: 6.w,
              ),
            ),
          ] else ...[
            IconButton(
              onPressed: _toggleSearch,
              icon: CustomIconWidget(
                iconName: _isSearching ? 'close' : 'search',
                color: Colors.white,
                size: 6.w,
              ),
            ),
            IconButton(
              onPressed: _toggleBulkSelect,
              icon: CustomIconWidget(
                iconName: 'checklist',
                color: Colors.white,
                size: 6.w,
              ),
            ),
          ],
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Import section
            Container(
              padding: EdgeInsets.all(4.w),
              color: AppTheme.lightTheme.colorScheme.surface,
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _showImportOptions,
                      icon: CustomIconWidget(
                        iconName: 'add',
                        color: Colors.white,
                        size: 5.w,
                      ),
                      label: const Text('Add Audio'),
                      style: AppTheme.lightTheme.elevatedButtonTheme.style,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${_audioFiles.length}',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Filter chips
            Container(
              height: 8.h,
              padding: EdgeInsets.symmetric(vertical: 1.h),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                itemCount: _filterOptions.length,
                itemBuilder: (context, index) {
                  final filter = _filterOptions[index];
                  return FilterChipWidget(
                    label: filter,
                    isSelected: _selectedFilter == filter,
                    onSelected: () => _onFilterSelected(filter),
                    count: _getFilterCount(filter),
                  );
                },
              ),
            ),

            // Audio files list
            Expanded(
              child: filteredFiles.isEmpty
                  ? EmptyStateWidget(
                      onImportPressed: _showImportOptions,
                    )
                  : RefreshIndicator(
                      onRefresh: _refreshAudioFiles,
                      color: AppTheme.lightTheme.colorScheme.primary,
                      child: ListView.builder(
                        controller: _scrollController,
                        padding: EdgeInsets.all(4.w),
                        itemCount: filteredFiles.length,
                        itemBuilder: (context, index) {
                          final audio = filteredFiles[index];
                          return AudioFileCardWidget(
                            audio: audio,
                            isSelected: _selectedAudioIds.contains(audio['id']),
                            isBulkSelectMode: _isBulkSelectMode,
                            onTap: () => _isBulkSelectMode
                                ? _toggleAudioSelection(audio['id'])
                                : _navigateToPractice(audio),
                            onFavoriteToggle: () =>
                                _toggleFavorite(audio['id']),
                            onDelete: () => _deleteAudio(audio['id']),
                            onShare: () => _shareAudio(audio),
                            onLongPress: () => _showContextMenu(audio),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  int _getFilterCount(String filter) {
    switch (filter) {
      case 'All':
        return _audioFiles.length;
      case 'Favorites':
        return _audioFiles.where((audio) => audio['isFavorite'] == true).length;
      case 'Recent':
        return _audioFiles.length > 10 ? 10 : _audioFiles.length;
      default:
        return _audioFiles
            .where((audio) => audio['difficulty'] == filter)
            .length;
    }
  }

  void _navigateToPractice(Map<String, dynamic> audio) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Starting practice with ${audio['title']}')),
    );
  }

  void _shareAudio(Map<String, dynamic> audio) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Sharing ${audio['title']}')),
    );
  }

  void _showContextMenu(Map<String, dynamic> audio) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              audio['title'],
              style: AppTheme.lightTheme.textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 3.h),
            _buildContextMenuItem(
              icon: 'play_arrow',
              title: 'Practice Now',
              onTap: () {
                Navigator.pop(context);
                _navigateToPractice(audio);
              },
            ),
            _buildContextMenuItem(
              icon: audio['isFavorite'] ? 'favorite' : 'favorite_border',
              title: audio['isFavorite']
                  ? 'Remove from Favorites'
                  : 'Add to Favorites',
              onTap: () {
                Navigator.pop(context);
                _toggleFavorite(audio['id']);
              },
            ),
            _buildContextMenuItem(
              icon: 'share',
              title: 'Share',
              onTap: () {
                Navigator.pop(context);
                _shareAudio(audio);
              },
            ),
            _buildContextMenuItem(
              icon: 'delete',
              title: 'Delete',
              isDestructive: true,
              onTap: () {
                Navigator.pop(context);
                _showDeleteConfirmation(audio);
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildContextMenuItem({
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.all(4.w),
        margin: EdgeInsets.only(bottom: 1.h),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: isDestructive
                  ? AppTheme.lightTheme.colorScheme.error
                  : AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: isDestructive
                    ? AppTheme.lightTheme.colorScheme.error
                    : AppTheme.lightTheme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(Map<String, dynamic> audio) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Audio File'),
        content: Text(
            'Are you sure you want to delete "${audio['title']}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteAudio(audio['id']);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
