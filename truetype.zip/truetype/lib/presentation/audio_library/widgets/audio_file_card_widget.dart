import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AudioFileCardWidget extends StatelessWidget {
  final Map<String, dynamic> audio;
  final bool isSelected;
  final bool isBulkSelectMode;
  final VoidCallback onTap;
  final VoidCallback onFavoriteToggle;
  final VoidCallback onDelete;
  final VoidCallback onShare;
  final VoidCallback onLongPress;

  const AudioFileCardWidget({
    Key? key,
    required this.audio,
    required this.isSelected,
    required this.isBulkSelectMode,
    required this.onTap,
    required this.onFavoriteToggle,
    required this.onDelete,
    required this.onShare,
    required this.onLongPress,
  }) : super(key: key);

  Color _getDifficultyColor() {
    switch (audio['difficulty']) {
      case 'Beginner':
        return Colors.green;
      case 'Intermediate':
        return Colors.orange;
      case 'Advanced':
        return Colors.red;
      case 'Expert':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        margin: EdgeInsets.only(bottom: 3.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primaryContainer
              : AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.outline,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.lightTheme.colorScheme.shadow,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with thumbnail and controls
            Container(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  // Bulk select checkbox
                  if (isBulkSelectMode) ...[
                    Checkbox(
                      value: isSelected,
                      onChanged: (_) => onTap,
                      activeColor: AppTheme.lightTheme.colorScheme.primary,
                    ),
                    SizedBox(width: 2.w),
                  ],

                  // Waveform thumbnail
                  Container(
                    width: 20.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: AppTheme.lightTheme.colorScheme.primaryContainer,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CustomImageWidget(
                        imageUrl: audio['waveformUrl'],
                        width: 20.w,
                        height: 12.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),

                  SizedBox(width: 4.w),

                  // Audio info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                audio['title'],
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (!isBulkSelectMode)
                              IconButton(
                                onPressed: onFavoriteToggle,
                                icon: CustomIconWidget(
                                  iconName: audio['isFavorite']
                                      ? 'favorite'
                                      : 'favorite_border',
                                  color: audio['isFavorite']
                                      ? Colors.red
                                      : AppTheme.lightTheme.colorScheme
                                          .onSurfaceVariant,
                                  size: 5.w,
                                ),
                              ),
                          ],
                        ),

                        SizedBox(height: 1.h),

                        // Duration and difficulty
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'access_time',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 4.w,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              audio['duration'],
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                            ),
                            SizedBox(width: 3.w),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color: _getDifficultyColor()
                                    .withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                audio['difficulty'],
                                style: AppTheme.lightTheme.textTheme.labelSmall
                                    ?.copyWith(
                                  color: _getDifficultyColor(),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 1.h),

                        // Last practiced
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'history',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 4.w,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              'Last practiced: ${audio['lastPracticed']}',
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Stats section
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.5),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              child: Row(
                children: [
                  // Accuracy
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Accuracy',
                          style: AppTheme.lightTheme.textTheme.labelSmall,
                        ),
                        SizedBox(height: 0.5.h),
                        Row(
                          children: [
                            Text(
                              '${audio['accuracy']}%',
                              style: AppTheme.lightTheme.textTheme.titleSmall
                                  ?.copyWith(
                                color: audio['accuracy'] >= 90
                                    ? Colors.green
                                    : audio['accuracy'] >= 80
                                        ? Colors.orange
                                        : Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(width: 1.w),
                            CustomIconWidget(
                              iconName: audio['accuracy'] >= 90
                                  ? 'trending_up'
                                  : audio['accuracy'] >= 80
                                      ? 'trending_flat'
                                      : 'trending_down',
                              color: audio['accuracy'] >= 90
                                  ? Colors.green
                                  : audio['accuracy'] >= 80
                                      ? Colors.orange
                                      : Colors.red,
                              size: 4.w,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Practice count
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Sessions',
                          style: AppTheme.lightTheme.textTheme.labelSmall,
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          '${audio['practiceCount']}',
                          style: AppTheme.lightTheme.textTheme.titleSmall
                              ?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // File size
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Size',
                          style: AppTheme.lightTheme.textTheme.labelSmall,
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          audio['fileSize'],
                          style: AppTheme.lightTheme.textTheme.titleSmall
                              ?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Action buttons
                  if (!isBulkSelectMode) ...[
                    IconButton(
                      onPressed: () {
                        // Preview play functionality
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content:
                                  Text('Playing preview of ${audio['title']}')),
                        );
                      },
                      icon: Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: CustomIconWidget(
                          iconName: 'play_arrow',
                          color: Colors.white,
                          size: 5.w,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
