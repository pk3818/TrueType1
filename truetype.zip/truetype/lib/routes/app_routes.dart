import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/audio_library/audio_library.dart';
import '../presentation/user_profile_settings/user_profile_settings.dart';
import '../presentation/real_time_transcription/real_time_transcription.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String splashScreen = '/splash-screen';
  static const String loginScreen = '/login-screen';
  static const String audioLibrary = '/audio-library';
  static const String userProfileSettings = '/user-profile-settings';
  static const String realTimeTranscription = '/real-time-transcription';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splashScreen: (context) => const SplashScreen(),
    loginScreen: (context) => const LoginScreen(),
    audioLibrary: (context) => const AudioLibrary(),
    userProfileSettings: (context) => const UserProfileSettings(),
    realTimeTranscription: (context) => const RealTimeTranscription(),
    // TODO: Add your other routes here
  };
}
